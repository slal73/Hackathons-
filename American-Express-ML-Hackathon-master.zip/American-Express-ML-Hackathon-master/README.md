# American-Express-ML-Hackathon
American Express hosted a machine learning hackathon (https://datahack.analyticsvidhya.com/contest/american-express-amexpert-2018/). Based on clickstream data, we have to  predict if the session will end in a adClick or not.

### XG Boost
I used xg boost for gradient boosting and produce a model of from weghted learners.

### Accuracy
Acheaved a mean accuracy of 91% (Checked with K-Cross validation method).
